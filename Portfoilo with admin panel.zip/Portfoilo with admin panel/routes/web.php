<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/welcome', 'PagesController@index'); // localhost:8000/
//Route::get('/{id}', 'PagesController@index');
Route::post('/save', 'PagesController@save');
//Route::get('/deleteUser/{id}', 'PagesController@deleteUser');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('delete-records','HomeController@index')->name('home');
Route::get('delete/{id}','HomeController@destroy')->name('home');

//Route::get('/home','datashow@index')->name('home');

//Route::get('/', 'PagesController@index');
//Route::get('/', 'PagesController@index'); // localhost:8000/
//Route::get('/{id}', 'PagesController@index');
//Route::post('/save', 'PagesController@save');
//Route::get('/deleteUser/{id}', 'PagesController@deleteUser');
